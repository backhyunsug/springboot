package com.woori.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisprojApplication {
 
	public static void main(String[] args) {
		SpringApplication.run(MybatisprojApplication.class, args);
	}
 
}
